<?php return array(
    'root' => array(
        'name' => 'sovit/festingervault',
        'pretty_version' => 'dev-beta',
        'version' => 'dev-beta',
        'reference' => '227f374ad76a6b8f25eb3f74edad7af4035310b9',
        'type' => 'project',
        'install_path' => __DIR__ . '/../../../',
        'aliases' => array(),
        'dev' => true,
    ),
    'versions' => array(
        'sovit/festingervault' => array(
            'pretty_version' => 'dev-beta',
            'version' => 'dev-beta',
            'reference' => '227f374ad76a6b8f25eb3f74edad7af4035310b9',
            'type' => 'project',
            'install_path' => __DIR__ . '/../../../',
            'aliases' => array(),
            'dev_requirement' => false,
        ),
    ),
);
